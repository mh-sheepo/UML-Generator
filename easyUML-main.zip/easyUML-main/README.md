# easyUML for all Netbeans versions
Includes easyUML plug-in .nbm files

Installation video link:
https://www.youtube.com/watch?v=KaUtssmQs6A
